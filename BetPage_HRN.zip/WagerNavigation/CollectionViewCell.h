//
//  CollectionViewCell.h
//  CollectionView
//
//  Created by pcs20 on 9/24/14.
//  Copyright (c) 2014 Paradigmcreatives. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CollectionViewCell : UICollectionViewCell

@property(nonatomic,strong)IBOutlet UILabel *rowLabel;

@end
